# Digital Menu Demo APK (V1)
A beginner starter Android WebView app containing a sample restaurant menu. The menu is demonstration content only; update restaurant details and menu/prices before client use.


## Build APK using GitHub Actions
1. Create a GitHub repository named `digital-menu-demo`.
2. Upload the contents of this folder to the repository root (not the enclosing folder).
3. Open the repository's **Actions** tab and select **Build APK** workflow.
4. Run workflow (or push to `main`); wait for it to finish.
5. Open the completed run, download artifact `DigitalMenu-Demo-APK`, unzip it, and install `app-debug.apk` on your Android phone. If Android asks, allow installing from that source.

This demo is offline except WhatsApp order links. The WhatsApp button uses a generic link and needs the restaurant WhatsApp number to be configured before client delivery.
